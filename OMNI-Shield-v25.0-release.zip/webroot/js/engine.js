// engine.js — OmniShield generation engine (mirrors jni/omni_engine.hpp exactly)
// Uses BigInt for 64-bit precision matching C++ std::mt19937_64

// ─── MD5 (RFC 1321, pure JS) ──────────────────────────────────────────────────
// Input: UTF-8 string. Output: 32-char lowercase hex.
function md5(str) {
  // Per-round shift amounts
  const S = [7,12,17,22, 7,12,17,22, 7,12,17,22, 7,12,17,22,
             5, 9,14,20, 5, 9,14,20, 5, 9,14,20, 5, 9,14,20,
             4,11,16,23, 4,11,16,23, 4,11,16,23, 4,11,16,23,
             6,10,15,21, 6,10,15,21, 6,10,15,21, 6,10,15,21];
  // K[i] = floor(abs(sin(i+1)) * 2^32)
  const K = [
    0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,
    0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
    0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
    0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
    0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,
    0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
    0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,
    0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391,
  ];
  // UTF-8 encode
  const msg = [];
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    if (c < 0x80) msg.push(c);
    else if (c < 0x800) msg.push(0xc0|(c>>6), 0x80|(c&0x3f));
    else msg.push(0xe0|(c>>12), 0x80|((c>>6)&0x3f), 0x80|(c&0x3f));
  }
  const msgLen = msg.length;
  // Padding: append 0x80 then zeros, then 64-bit LE bit-length
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  let bits = msgLen * 8;
  for (let i = 0; i < 8; i++) { msg.push(bits & 0xff); bits >>>= 8; }
  // Initial hash state
  let h0 = 0x67452301|0, h1 = 0xefcdab89|0, h2 = 0x98badcfe|0, h3 = 0x10325476|0;
  // Process 512-bit blocks
  for (let ofs = 0; ofs < msg.length; ofs += 64) {
    const W = new Int32Array(16);
    for (let j = 0; j < 16; j++)
      W[j] = msg[ofs+j*4] | (msg[ofs+j*4+1]<<8) | (msg[ofs+j*4+2]<<16) | (msg[ofs+j*4+3]<<24);
    let a = h0, b = h1, c = h2, d = h3;
    for (let i = 0; i < 64; i++) {
      let f, g;
      if      (i < 16) { f = (b & c) | (~b & d); g = i; }
      else if (i < 32) { f = (d & b) | (~d & c); g = (5*i+1) % 16; }
      else if (i < 48) { f = b ^ c ^ d;           g = (3*i+5) % 16; }
      else             { f = c ^ (b | ~d);         g = (7*i)   % 16; }
      f = (f + a + K[i] + W[g]) | 0;
      a = d; d = c; c = b;
      b = (b + ((f << S[i]) | (f >>> (32-S[i])))) | 0;
    }
    h0 = (h0+a)|0; h1 = (h1+b)|0; h2 = (h2+c)|0; h3 = (h3+d)|0;
  }
  const le32 = v => { let s='', u=v>>>0; for (let i=0;i<4;i++) s+=((u>>>(i*8))&0xff).toString(16).padStart(2,'0'); return s; };
  return le32(h0)+le32(h1)+le32(h2)+le32(h3);
}
// Self-test: RFC 1321 test vectors + JA3 string hashes (catches any MD5 regression)
if (md5('abc') !== '900150983cd24fb0d6963f7d28e17f72')
  throw new Error('OmniShield: MD5 self-test failed (abc)');
if (md5('771,4865-4866-4867-49195-49199-49196-49200-52392-52393-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-27-17513-21,29-23-24,0') !== '77d1a489ef746d17cc0cd09f2de71b5d')
  throw new Error('OmniShield: MD5 self-test failed (Chrome 120 JA3 string)');
if (md5('771,4865-4866-4867-49195-49199-49196-49200-52392-52393-49171-49172-156-157-47-53,0-23-65281-10-11-35-16-5-13-18-51-45-43-21,29-23-24,0') !== '479dc4a100ab08c520e0adfe30107d65')
  throw new Error('OmniShield: MD5 self-test failed (OkHttp 4.x JA3 string)');

// ─── MT19937-64 (matches std::mt19937_64) ────────────────────────────────────
class MT64 {
  constructor(seed) {
    this.N = 312; this.M = 156;
    this.MATRIX_A = 0xB5026F5AA96619E9n;
    this.UM = 0xFFFFFFFF80000000n;
    this.LM = 0x7FFFFFFFn;
    this.M64 = 0xFFFFFFFFFFFFFFFFn;
    this.mt = new Array(312).fill(0n);
    this.mti = 312;
    const s = BigInt(seed < 0 ? -seed : seed);
    this.mt[0] = s & this.M64;
    for (let i = 1; i < 312; i++) {
      const p = this.mt[i - 1];
      this.mt[i] = (6364136223846793005n * (p ^ (p >> 62n)) + BigInt(i)) & this.M64;
    }
  }
  gen() {
    const {N,M,MATRIX_A,UM,LM,M64} = this;
    const mag = [0n, MATRIX_A];
    if (this.mti >= N) {
      let k;
      for (k = 0; k < N - M; k++) {
        const x = (this.mt[k] & UM) | (this.mt[k+1] & LM);
        this.mt[k] = this.mt[k+M] ^ (x >> 1n) ^ mag[Number(x & 1n)];
      }
      for (; k < N - 1; k++) {
        const x = (this.mt[k] & UM) | (this.mt[k+1] & LM);
        this.mt[k] = this.mt[k+(M-N)] ^ (x >> 1n) ^ mag[Number(x & 1n)];
      }
      const x = (this.mt[N-1] & UM) | (this.mt[0] & LM);
      this.mt[N-1] = this.mt[M-1] ^ (x >> 1n) ^ mag[Number(x & 1n)];
      this.mti = 0;
    }
    let y = this.mt[this.mti++];
    y ^= (y >> 29n) & 0x5555555555555555n;
    y ^= (y << 17n) & 0x71D67FFFEDA60000n;
    y ^= (y << 37n) & 0xFFF7EEE000000000n;
    y ^= y >> 43n;
    return y & M64;
  }
}

class OmniRandom {
  constructor(seed) { this._rng = new MT64(seed); }
  nextInt(bound) { return Number(this._rng.gen() % BigInt(bound)); }
  nextFloat(min, max) {
    const v = Number(this._rng.gen() & 0xFFFFFFFFn) / 4294967295;
    return min + v * (max - min);
  }
}

// ─── TAC pools (mirrors TACS_BY_BRAND in omni_engine.hpp) ────────────────────
const TACS = {
  xiaomi:   ["86413404","86413405","35271311","35361311","86814904","86814905"],
  poco:     ["86814904","86814905","35847611","35847612","35847613","35847614"],
  redmi:    ["86413404","86413405","35271311","35271312","35271313","35271314"],
  samsung:  ["35449209","35449210","35355610","35735110","35735111","35843110","35940210"],
  google:   ["35674910","35674911","35308010","35308011","35908610","35908611"],
  oneplus:  ["86882504","86882505","35438210","35438211","35438212","35438213"],
  motorola: ["35617710","35617711","35327510","35327511","35327512","35327513"],
  nokia:    ["35720210","35720211","35489310","35489311","35654110","35654111"],
  realme:   ["86828804","86828805","35388910","35388911","35388912","35388913"],
  vivo:     ["86979604","86979605","35503210","35503211","35503212","35503213"],
  oppo:     ["86885004","86885005","35604210","35604211","35604212","35604213"],
  asus:     ["35851710","35851711","35325010","35325011","35325012","35325013"],
  "hmd global":["35720210","35720211","35489310","35489311"],
  infinix:  ["35318491","35318492","35318493","35884011","35884012","35884013"],
  tecno:    ["35779310","35779311","35779312","35779313","35779314","35779315"],
  default:  ["35271311","35449209","35674910","35438210","35617710"]
};

// OUI pools — fallback only (no Qualcomm OUIs; all profiles are MediaTek)
const OUIS = [
  [0x60,0x57,0x18],[0xAC,0x37,0x43],[0x00,0x90,0x4C],  // MediaTek
  [0xD4,0xBE,0xD9],[0xA4,0xC3,0xF0],[0xF8,0x8F,0xCA],  // Broadcom (common in MTK phones)
  [0x40,0x9B,0xCD],[0x24,0x4B,0x03]                     // Samsung
];

// IMSI pools (USA carriers, mirrors IMSI_POOLS in omni_engine.hpp)
const IMSI_POOLS = ["310260","310410","311480","310120","311580"];
//                  T-Mobile  AT&T    Verizon  Sprint   US Cellular

const CARRIER_NAMES = {
  "310260":"T-Mobile","310410":"AT&T","311480":"Verizon Wireless",
  "310120":"T-Mobile","311580":"U.S. Cellular"
};

// US cities for GPS (mirrors US_CITIES in omni_engine.hpp)
const US_CITIES_5 = [
  {lat:40.7128, lon:-74.0060, name:"New York"},
  {lat:34.0522, lon:-118.2437, name:"Los Angeles"},
  {lat:41.8781, lon:-87.6298, name:"Chicago"},
  {lat:29.7604, lon:-95.3698, name:"Houston"},
  {lat:33.4484, lon:-112.0740, name:"Phoenix"}
];

const US_CITIES_100 = [
  {lat:40.7128,lon:-74.0060,name:"New York, NY"},
  {lat:34.0522,lon:-118.2437,name:"Los Angeles, CA"},
  {lat:41.8781,lon:-87.6298,name:"Chicago, IL"},
  {lat:29.7604,lon:-95.3698,name:"Houston, TX"},
  {lat:33.4484,lon:-112.0740,name:"Phoenix, AZ"},
  {lat:29.4241,lon:-98.4936,name:"San Antonio, TX"},
  {lat:32.7767,lon:-96.7970,name:"Dallas, TX"},
  {lat:30.3322,lon:-81.6557,name:"Jacksonville, FL"},
  {lat:30.2672,lon:-97.7431,name:"Austin, TX"},
  {lat:30.3960,lon:-86.4981,name:"Fort Worth, TX"},
  {lat:37.3382,lon:-121.8863,name:"San Jose, CA"},
  {lat:30.3322,lon:-81.6557,name:"Columbus, OH"},
  {lat:35.2271,lon:-80.8431,name:"Charlotte, NC"},
  {lat:39.7392,lon:-104.9903,name:"Denver, CO"},
  {lat:39.9526,lon:-75.1652,name:"Philadelphia, PA"},
  {lat:47.6062,lon:-122.3321,name:"Seattle, WA"},
  {lat:36.1699,lon:-115.1398,name:"Las Vegas, NV"},
  {lat:36.1627,lon:-86.7816,name:"Nashville, TN"},
  {lat:30.2241,lon:-92.0198,name:"Oklahoma City, OK"},
  {lat:35.4676,lon:-97.5164,name:"Tulsa, OK"},
  {lat:37.7749,lon:-122.4194,name:"San Francisco, CA"},
  {lat:35.1495,lon:-90.0490,name:"Memphis, TN"},
  {lat:43.0481,lon:-76.1474,name:"Louisville, KY"},
  {lat:38.2527,lon:-85.7585,name:"Baltimore, MD"},
  {lat:39.2904,lon:-76.6122,name:"Milwaukee, WI"},
  {lat:43.0389,lon:-76.1528,name:"Albuquerque, NM"},
  {lat:35.0844,lon:-106.6504,name:"Tucson, AZ"},
  {lat:32.2226,lon:-110.9747,name:"Fresno, CA"},
  {lat:36.7378,lon:-119.7871,name:"Sacramento, CA"},
  {lat:38.5816,lon:-121.4944,name:"Mesa, AZ"},
  {lat:33.4152,lon:-111.8315,name:"Kansas City, MO"},
  {lat:39.0997,lon:-94.5786,name:"Atlanta, GA"},
  {lat:33.7490,lon:-84.3880,name:"Omaha, NE"},
  {lat:41.2565,lon:-95.9345,name:"Colorado Springs, CO"},
  {lat:38.8339,lon:-104.8214,name:"Raleigh, NC"},
  {lat:35.7796,lon:-78.6382,name:"Long Beach, CA"},
  {lat:33.7701,lon:-118.1937,name:"Virginia Beach, VA"},
  {lat:36.8529,lon:-75.9780,name:"Minneapolis, MN"},
  {lat:44.9778,lon:-93.2650,name:"Tampa, FL"},
  {lat:27.9506,lon:-82.4572,name:"New Orleans, LA"},
  {lat:29.9511,lon:-90.0715,name:"Arlington, TX"},
  {lat:32.7357,lon:-97.1081,name:"Bakersfield, CA"},
  {lat:35.3733,lon:-119.0187,name:"Honolulu, HI"},
  {lat:21.3069,lon:-157.8583,name:"Anaheim, CA"},
  {lat:33.8353,lon:-117.9145,name:"Aurora, CO"},
  {lat:39.7294,lon:-104.8319,name:"Santa Ana, CA"},
  {lat:33.7455,lon:-117.8677,name:"Corpus Christi, TX"},
  {lat:27.8006,lon:-97.3964,name:"Riverside, CA"},
  {lat:33.9533,lon:-117.3962,name:"Lexington, KY"},
  {lat:38.0406,lon:-84.5037,name:"St. Louis, MO"},
  {lat:38.6270,lon:-90.1994,name:"Pittsburgh, PA"},
  {lat:40.4406,lon:-79.9959,name:"Stockton, CA"},
  {lat:37.9577,lon:-121.2908,name:"Anchorage, AK"},
  {lat:61.2181,lon:-149.9003,name:"Cincinnati, OH"},
  {lat:39.1031,lon:-84.5120,name:"St. Paul, MN"},
  {lat:44.9537,lon:-93.0900,name:"Toledo, OH"},
  {lat:41.6639,lon:-83.5552,name:"Greensboro, NC"},
  {lat:36.0726,lon:-79.7920,name:"Newark, NJ"},
  {lat:40.7357,lon:-74.1724,name:"Plano, TX"},
  {lat:33.0198,lon:-96.6989,name:"Henderson, NV"},
  {lat:36.0395,lon:-114.9817,name:"Lincoln, NE"},
  {lat:40.8136,lon:-96.7026,name:"Buffalo, NY"},
  {lat:42.8864,lon:-78.8784,name:"Fort Wayne, IN"},
  {lat:41.0793,lon:-85.1394,name:"Jersey City, NJ"},
  {lat:40.7178,lon:-74.0431,name:"Chula Vista, CA"},
  {lat:32.6401,lon:-117.0842,name:"Orlando, FL"},
  {lat:28.5383,lon:-81.3792,name:"St. Petersburg, FL"},
  {lat:27.7676,lon:-82.6403,name:"Laredo, TX"},
  {lat:27.5064,lon:-99.5075,name:"Norfolk, VA"},
  {lat:36.8508,lon:-76.2859,name:"Madison, WI"},
  {lat:43.0731,lon:-89.4012,name:"Durham, NC"},
  {lat:35.9940,lon:-78.8986,name:"Lubbock, TX"},
  {lat:33.5779,lon:-101.8552,name:"Winston-Salem, NC"},
  {lat:36.0999,lon:-80.2442,name:"Garland, TX"},
  {lat:32.9126,lon:-96.6389,name:"Glendale, AZ"},
  {lat:33.5387,lon:-112.1860,name:"Hialeah, FL"},
  {lat:25.8576,lon:-80.2781,name:"Reno, NV"},
  {lat:39.5296,lon:-119.8138,name:"Baton Rouge, LA"},
  {lat:30.4515,lon:-91.1871,name:"Irvine, CA"},
  {lat:33.6846,lon:-117.8265,name:"Chesapeake, VA"},
  {lat:36.7682,lon:-76.2875,name:"Irving, TX"},
  {lat:32.8140,lon:-96.9489,name:"Scottsdale, AZ"},
  {lat:33.4942,lon:-111.9261,name:"North Las Vegas, NV"},
  {lat:36.1989,lon:-115.1175,name:"Fremont, CA"},
  {lat:37.5485,lon:-121.9886,name:"Gilbert, AZ"},
  {lat:33.3528,lon:-111.7890,name:"San Bernardino, CA"},
  {lat:34.1083,lon:-117.2898,name:"Boise, ID"},
  {lat:43.6187,lon:-116.2146,name:"Birmingham, AL"},
  {lat:33.5207,lon:-86.8025,name:"Rochester, NY"},
  {lat:43.1566,lon:-77.6088,name:"Richmond, VA"},
  {lat:37.5407,lon:-77.4360,name:"Spokane, WA"},
  {lat:47.6588,lon:-117.4260,name:"Des Moines, IA"},
  {lat:41.5868,lon:-93.6250,name:"Montgomery, AL"},
  {lat:32.3668,lon:-86.3000,name:"Modesto, CA"},
  {lat:37.6391,lon:-120.9969,name:"Fayetteville, NC"},
  {lat:35.0527,lon:-78.8784,name:"Tacoma, WA"},
  {lat:47.2529,lon:-122.4443,name:"Shreveport, LA"},
  {lat:32.5252,lon:-93.7502,name:"Akron, OH"},
  {lat:41.0814,lon:-81.5190,name:"Aurora, IL"},
  {lat:41.7606,lon:-88.3201,name:"Little Rock, AR"},
  {lat:34.7465,lon:-92.2896,name:"Augusta, GA"}
];

// Altitude base per city (US_CITIES_5)
const US_ALT = [
  {base:10,range:25}, {base:50,range:70}, {base:180,range:20},
  {base:10,range:15}, {base:330,range:30}
];

const US_TIMEZONES = [
  "America/New_York","America/Los_Angeles","America/Chicago",
  "America/Chicago","America/Phoenix"
];

// ─── Luhn checksum (mirrors luhnChecksum in omni_engine.hpp) ─────────────────
function luhnDigit(base14) {
  let sum = 0;
  const len = base14.length;
  for (let i = len - 1; i >= 0; i--) {
    let d = parseInt(base14[i]);
    if ((len - 1 - i) % 2 === 0) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return (10 - (sum % 10)) % 10;
}

// ─── IMEI generation (exact mirror of generateValidImei) ─────────────────────
export function generateIMEI(profileName, seed) {
  const rng = new OmniRandom(seed);
  const brand = getEffectiveBrand(profileName).toLowerCase();
  const isQualcomm = isAdreno(profileName);

  let tacList = TACS[brand] || TACS.default;
  let tac;
  if (brand === 'redmi' && isQualcomm) {
    const qTacs = ["35271311","35271312","35271313","35271314"];
    tac = qTacs[rng.nextInt(qTacs.length)];
  } else {
    tac = tacList[rng.nextInt(tacList.length)];
  }
  let serial = '';
  for (let i = 0; i < 6; i++) serial += rng.nextInt(10);
  const base = tac + serial;
  return base + luhnDigit(base);
}

// ─── ICCID generation (mirrors generateValidIccid) ───────────────────────────
export function generateICCID(profileName, seed) {
  const rng = new OmniRandom(seed);
  let iccid = '89101';
  for (let i = 0; i < 13; i++) iccid += rng.nextInt(10);
  return iccid + luhnDigit(iccid);
}

// ─── IMSI generation (mirrors generateValidImsi) ─────────────────────────────
export function generateIMSI(profileName, seed) {
  const rng = new OmniRandom(seed);
  const mccMnc = IMSI_POOLS[rng.nextInt(IMSI_POOLS.length)];
  const remaining = 15 - mccMnc.length;
  let rest = String(2 + rng.nextInt(8));
  for (let i = 1; i < remaining; i++) rest += rng.nextInt(10);
  return mccMnc + rest;
}

// ─── Phone number (mirrors generatePhoneNumber, seed+777) ────────────────────
export function generatePhoneNumber(profileName, seed) {
  const rng = new OmniRandom(seed + 777);
  let npa, nxx;
  do {
    npa  = String(2 + rng.nextInt(8));
    npa += rng.nextInt(10);
    npa += rng.nextInt(10);
  } while ((npa[1] === '1' && npa[2] === '1') || npa === '555');
  do {
    nxx  = String(2 + rng.nextInt(8));
    nxx += rng.nextInt(10);
    nxx += rng.nextInt(10);
  } while (nxx[1] === '1' && nxx[2] === '1');
  let sub = '';
  for (let i = 0; i < 4; i++) sub += rng.nextInt(10);
  return '+1' + npa + nxx + sub;
}

// ─── MAC address (mirrors generateRandomMac) ─────────────────────────────────
export function generateMAC(brandIn, seed) {
  const rng = new OmniRandom(seed);
  const brand = (brandIn || '').toLowerCase();
  let oui;
  if (brand === 'samsung') {
    // Samsung Electronics registered OUIs
    const pool = [[0x24,0x4B,0x03],[0x40,0x9B,0xCD],[0xD4,0xBE,0xD9]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (brand === 'google') {
    const pool = [[0xF8,0x8F,0xCA],[0xA4,0xC3,0xF0]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (['xiaomi','redmi','poco'].includes(brand)) {
    // Xiaomi Communications Co., Ltd registered OUIs
    const pool = [[0x40,0x31,0x3C],[0xF4,0x8B,0x32],[0x28,0xE3,0x1F],[0x6C,0xE8,0x5C]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (brand === 'oneplus') {
    oui = [0x40,0x4E,0x36];
  } else if (brand === 'motorola') {
    // Motorola Mobility LLC registered OUIs
    const pool = [[0xDC,0x2B,0x2A],[0x40,0xCE,0x24],[0xCC,0xF9,0x54]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (['realme','oppo'].includes(brand)) {
    // OPPO Electronics Corp Ltd registered OUIs (Realme parent)
    const pool = [[0xAC,0x2B,0xA1],[0x60,0x7F,0x66],[0x14,0x7D,0xDA]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (brand === 'vivo') {
    // Vivo Mobile Communication Co., Ltd registered OUIs
    const pool = [[0xD0,0xB8,0xAA],[0x54,0x8C,0xA0],[0xB4,0x3A,0x28]];
    oui = pool[rng.nextInt(pool.length)];
  } else if (['infinix','tecno'].includes(brand)) {
    // TRANSSION Holdings registered OUIs
    const pool = [[0x40,0xED,0x7E],[0x80,0xB0,0x3D],[0xA4,0x9A,0x58]];
    oui = pool[rng.nextInt(pool.length)];
  } else {
    oui = OUIS[rng.nextInt(OUIS.length)];
  }
  const parts = oui.map(b => b.toString(16).padStart(2,'0'));
  for (let i = 0; i < 3; i++) parts.push(rng.nextInt(256).toString(16).padStart(2,'0'));
  return parts.join(':');
}

// ─── Serial number (mirrors generateRandomSerial) ────────────────────────────
export function generateSerial(brandIn, seed, securityPatch) {
  const rng = new OmniRandom(seed);
  const brand = (brandIn || '').toLowerCase();
  if (brand === 'samsung') {
    const plants = ['R','R','S','X'];
    const plant = plants[rng.nextInt(plants.length)];
    const factories = ['F8','58','28','R1','S1'];
    const factory = factories[rng.nextInt(factories.length)];
    let year = 2021;
    if (securityPatch && securityPatch.length >= 4) year = parseInt(securityPatch.slice(0,4)) || 2021;
    const yc = {2019:'R',2020:'S',2021:'T',2022:'U',2023:'V'}[year] || 'T';
    const months = '123456789ABC';
    const month = months[rng.nextInt(months.length)];
    let u = '';
    for (let i = 0; i < 6; i++) u += '0123456789ABCDEF'[rng.nextInt(16)];
    return plant + factory + yc + month + u;
  }
  if (brand === 'google') {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    let res = '';
    for (let i = 0; i < 7; i++) res += chars[rng.nextInt(chars.length)];
    return res;
  }
  const an = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  // Brand-specific serial lengths matching real OEM formats
  let len;
  if (['xiaomi','redmi','poco'].includes(brand))      len = 13; // e.g. WJW3KCY0XAABB
  else if (brand === 'motorola')                      len = 10; // e.g. ZU3CG6BF8X
  else if (['realme','oppo'].includes(brand))         len = 11; // e.g. RZ8M21BVMHB
  else if (brand === 'vivo')                          len = 12; // e.g. V2103PKTFKXV
  else if (['infinix','tecno'].includes(brand))       len = 13; // e.g. X693BNBMK02A4
  else                                                len = 8 + rng.nextInt(5);
  let res = '';
  for (let i = 0; i < len; i++) res += an[rng.nextInt(an.length)];
  return res;
}

// ─── JA3 fingerprint (Salesforce algorithm, seed-derived) ────────────────────
// Generates a real JA3 hash: MD5("SSLVersion,Ciphers,Extensions,Curves,PointFormats")
// Hash space: ~280 unique valid hashes (Chrome 119-122 / Samsung Internet / OkHttp 4.x).
// Seed offset +8001 reserved for this function; caller adds ja3Idx*10007 for variation.
export function generateJA3(seed, brand) {
  const rng = new OmniRandom(seed);
  const br = (brand || '').toLowerCase();

  // Samsung Internet is Chromium-based → always Chrome family
  const isOkHttp = br !== 'samsung' && rng.nextInt(2) === 0;

  // Cipher variation: ECDHE-CBC pair (49171,49172) and RSA-CBC pair (47,53) drop independently
  // — different Chrome versions remove them at different points in their release history
  const dropECDHE_CBC = rng.nextInt(2) === 0;  // eliminates 49171 + 49172
  const dropRSA_CBC   = rng.nextInt(2) === 0;  // eliminates 47 + 53
  const baseCiphers = [4865,4866,4867,49195,49199,49196,49200,52392,52393,49171,49172,156,157,47,53];
  const ciphers = baseCiphers.filter(c =>
    !(dropECDHE_CBC && (c === 49171 || c === 49172)) &&
    !(dropRSA_CBC   && (c === 47    || c === 53))
  );

  // Curves: some Chrome Android builds include secp521r1 (25) after secp384r1 (24)
  const hasSecp521 = rng.nextInt(4) === 0;  // 25% probability
  const curvesStr  = hasSecp521 ? '29-23-24-25' : '29-23-24';

  let exts, name;
  if (isOkHttp) {
    // OkHttp 4.x: SCT (ext 18) optional — some OkHttp/Retrofit builds omit it
    const okHasSct   = rng.nextInt(2) === 1;  // ext 18 signed_cert_timestamp
    const hasPadding = rng.nextInt(2) === 1;  // ext 21 padding (always last)
    exts = [0, 23, 65281, 10, 11, 35, 16, 5, 13];
    if (okHasSct) exts.push(18);
    exts.push(51, 45, 43);
    if (hasPadding) exts.push(21);
    name = `OkHttp/4.${10 + rng.nextInt(3)}.0`;
  } else {
    // Chrome / Samsung Internet: core extensions + seed-controlled optionals
    const hasSct      = rng.nextInt(2) === 1;  // ext 18    signed_cert_timestamp
    const hasCmpCrt   = rng.nextInt(2) === 1;  // ext 27    compress_cert
    const hasAlps     = rng.nextInt(2) === 1;  // ext 17513 application_settings (ALPS)
    const hasDelegCrd = rng.nextInt(4) === 0;  // ext 34    delegated_credentials (Chrome 105+, ~25%)
    const hasPadding  = rng.nextInt(2) === 1;  // ext 21    padding (always last)
    exts = [0, 23, 65281, 10, 11, 35, 16, 5, 13];
    if (hasSct)      exts.push(18);
    exts.push(51, 45, 43);
    if (hasCmpCrt)   exts.push(27);
    if (hasAlps)     exts.push(17513);
    if (hasDelegCrd) exts.push(34);
    if (hasPadding)  exts.push(21);
    name = br === 'samsung'
      ? `Samsung Internet ${23 + rng.nextInt(2)}`
      : `Chrome ${119 + rng.nextInt(4)} Android`;
  }

  const ja3str = `771,${ciphers.join('-')},${exts.join('-')},${curvesStr},0`;
  return { name, hash: md5(ja3str) };
}

// ─── Random ID (hex, mirrors generateRandomId) ───────────────────────────────
export function generateHexId(len, seed) {
  const rng = new OmniRandom(seed);
  const chars = '0123456789abcdef';
  let res = '';
  for (let i = 0; i < len; i++) res += chars[rng.nextInt(16)];
  return res;
}

// Android ID (16 hex chars, same as generateRandomId(16, seed))
export function generateAndroidId(seed) { return generateHexId(16, seed); }

// GSF ID (16 hex chars, seed+1)
export function generateGsfId(seed) { return generateHexId(16, seed + 1); }

// Widevine ID (32 hex chars, mirrors generateWidevineId)
export function generateWidevineId(seed) {
  const rng = new OmniRandom(seed);
  let res = '';
  for (let i = 0; i < 16; i++) res += rng.nextInt(256).toString(16).padStart(2,'0');
  return res;
}

// Boot ID (UUID format, seed+2)
export function generateBootId(seed) {
  const rng = new OmniRandom(seed + 2);
  const hex = (n) => rng.nextInt(256).toString(16).padStart(2,'0');
  const s = (n) => Array.from({length:n},()=>rng.nextInt(16).toString(16)).join('');
  return `${s(8)}-${s(4)}-4${s(3)}-${(8|rng.nextInt(4)).toString(16)}${s(3)}-${s(12)}`;
}

// ─── Location (mirrors generateLocationForRegion) ────────────────────────────
export function generateLocation(profileName, seed) {
  const cityRng = new OmniRandom(seed + 7777);
  const jitterRng = new OmniRandom(seed + 9999);
  const idx = cityRng.nextInt(5);
  const city = US_CITIES_5[idx];
  const jLat = (jitterRng.nextInt(4000) - 2000) / 100000;
  const jLon = (jitterRng.nextInt(4000) - 2000) / 100000;
  return { lat: city.lat + jLat, lon: city.lon + jLon, cityName: city.name };
}

export function generateAltitude(profileName, seed) {
  const cityRng = new OmniRandom(seed + 7777);
  const altRng = new OmniRandom(seed + 8888);
  const idx = cityRng.nextInt(5);
  const a = US_ALT[idx];
  return a.base + altRng.nextInt(a.range);
}

export function getTimezone(seed) {
  const rng = new OmniRandom(seed + 7777);
  return US_TIMEZONES[rng.nextInt(5)];
}

// ─── Carrier name from IMSI ───────────────────────────────────────────────────
export function getCarrierName(profileName, seed) {
  const imsi = generateIMSI(profileName, seed);
  const mccMnc = imsi.substr(0, 6);
  return CARRIER_NAMES[mccMnc] || 'T-Mobile';
}

export function getSimCountry(profileName, seed) { return 'US'; }

// ─── Helpers ─────────────────────────────────────────────────────────────────
function getEffectiveBrand(profileName) {
  // Import-free lookup using profile name string
  const lower = profileName.toLowerCase();
  if (lower.includes('galaxy') || lower.startsWith('sm-')) return 'samsung';
  if (lower.includes('pixel')) return 'google';
  if (lower.includes('poco')) return 'poco';
  if (lower.startsWith('redmi')) return 'redmi';
  if (lower.includes('mi ') || lower.startsWith('xiaomi')) return 'xiaomi';
  if (lower.includes('oneplus') || lower.startsWith('op')) return 'oneplus';
  if (lower.startsWith('moto')) return 'motorola';
  if (lower.includes('nokia')) return 'nokia';
  if (lower.includes('realme')) return 'realme';
  if (lower.includes('asus')) return 'asus';
  if (lower.startsWith('tecno') || lower.includes('tecno')) return 'tecno';
  if (lower.startsWith('infinix') || lower.includes('infinix')) return 'infinix';
  if (lower.startsWith('vivo') || lower.includes('vivo')) return 'vivo';
  if (lower.startsWith('oppo') || lower.includes('oppo')) return 'oppo';
  return 'default';
}

function isAdreno(profileName) {
  const n = profileName.toLowerCase();
  return n.includes('poco') || n.includes('mi 10') || n.includes('mi 11') ||
         n.includes('note 10 pro') || n.includes('note 9 pro') || n.includes('note 10') ||
         n.includes('poco f3') || n.includes('poco x3') || n.includes('x3 nfc') ||
         n.includes('galaxy a52') || n.includes('galaxy a72') || n.includes('galaxy s20') ||
         n.includes('oneplus') || n.includes('pixel') || n.includes('moto') ||
         n.includes('nokia 8') || n.includes('realme');
}

// ─── Validators ──────────────────────────────────────────────────────────────
export function validateIMEI(v) {
  if (!/^\d{15}$/.test(v)) return false;
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    let d = parseInt(v[i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return (10 - (sum % 10)) % 10 === parseInt(v[14]);
}

export function validateIMSI(v) {
  if (!/^\d{15}$/.test(v)) return false;
  const pfx = v.substr(0,6);
  return IMSI_POOLS.includes(pfx);
}

export function validateICCID(v) {
  if (!/^\d{19,20}$/.test(v) || !v.startsWith('89101')) return false;
  const base = v.slice(0,-1);
  let sum = 0;
  for (let i = 0; i < base.length; i++) {
    let d = parseInt(base[i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return (10 - (sum % 10)) % 10 === parseInt(v.slice(-1));
}

export function validateMAC(v) { return /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i.test(v); }
export function validatePhone(v) { return /^\+1[2-9]\d{2}[2-9]\d{6}$/.test(v); }
export function validateAndroidId(v) { return /^[0-9a-f]{16}$/.test(v); }
export function validateGsfId(v) { return /^[0-9a-f]{16}$/.test(v); }
export function validateWidevineId(v) { return /^[0-9a-f]{32}$/.test(v); }
export function validateBootId(v) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
}
export function validateSerial(v) { return v && v.length >= 8 && /^[A-Z0-9]+$/i.test(v); }

// ─── OUI pools per brand (for MAC OUI brand matching) ─────────────────────────
const BRAND_OUIS = {
  samsung:  [[0x24,0x4B,0x03],[0x40,0x9B,0xCD],[0xD4,0xBE,0xD9]],
  google:   [[0xF8,0x8F,0xCA],[0xA4,0xC3,0xF0]],
  // Xiaomi Communications Co., Ltd
  xiaomi:   [[0x40,0x31,0x3C],[0xF4,0x8B,0x32],[0x28,0xE3,0x1F],[0x6C,0xE8,0x5C]],
  redmi:    [[0x40,0x31,0x3C],[0xF4,0x8B,0x32],[0x28,0xE3,0x1F],[0x6C,0xE8,0x5C]],
  poco:     [[0x40,0x31,0x3C],[0xF4,0x8B,0x32],[0x28,0xE3,0x1F],[0x6C,0xE8,0x5C]],
  oneplus:  [[0x40,0x4E,0x36]],
  // Motorola Mobility LLC
  motorola: [[0xDC,0x2B,0x2A],[0x40,0xCE,0x24],[0xCC,0xF9,0x54]],
  // OPPO Electronics Corp Ltd (Realme parent)
  realme:   [[0xAC,0x2B,0xA1],[0x60,0x7F,0x66],[0x14,0x7D,0xDA]],
  oppo:     [[0xAC,0x2B,0xA1],[0x60,0x7F,0x66],[0x14,0x7D,0xDA]],
  // Vivo Mobile Communication Co., Ltd
  vivo:     [[0xD0,0xB8,0xAA],[0x54,0x8C,0xA0],[0xB4,0x3A,0x28]],
  // TRANSSION Holdings
  infinix:  [[0x40,0xED,0x7E],[0x80,0xB0,0x3D],[0xA4,0x9A,0x58]],
  tecno:    [[0x40,0xED,0x7E],[0x80,0xB0,0x3D],[0xA4,0x9A,0x58]],
};

// ─── Brand-contextual validators ─────────────────────────────────────────────
// These combine format validation with brand-pool membership, so a badge reflects
// whether the value belongs to the *current* profile's brand, not just a valid format.

export function imeiMatchesBrand(imei, profileName) {
  const brand = getEffectiveBrand(profileName).toLowerCase();
  const brandTacs = TACS[brand] || TACS.default;
  return brandTacs.some(t => imei.startsWith(t));
}

export function macMatchesBrand(mac, profileName) {
  const brand = getEffectiveBrand(profileName).toLowerCase();
  const pool = BRAND_OUIS[brand];
  if (!pool) return true;  // unknown brand → no OUI constraint
  const parts = mac.split(':').slice(0, 3).map(h => parseInt(h, 16));
  return pool.some(o => o[0] === parts[0] && o[1] === parts[1] && o[2] === parts[2]);
}

export function serialMatchesBrand(serial, profileName) {
  const brand = getEffectiveBrand(profileName).toLowerCase();
  if (brand === 'samsung') return /^[RSXZ][A-Z0-9]{2}[A-Z][A-Z0-9]{7,}$/i.test(serial);
  if (brand === 'google')  return /^[A-HJ-NP-Z0-9]{7}$/i.test(serial);
  return validateSerial(serial);  // other brands: generic length/charset check
}

// ─── Correlation score ────────────────────────────────────────────────────────
// Returns { score: 0-100, checks: [{name, passed, weight}] }
// Each check validates whether a generated value is coherent with the profile.
export function computeCorrelation(profileName, seed, ids = {}) {
  if (!profileName || !seed) return { score: 0, checks: [] };

  const brand = getEffectiveBrand(profileName).toLowerCase();
  const checks = [];
  const add = (name, weight, passed) => checks.push({ name, weight, passed });

  // ── 1. IMEI TAC matches profile brand (20)
  const imei = ids.imei || generateIMEI(profileName, seed);
  const brandTacs = TACS[brand] || TACS.default;
  add('IMEI TAC → ' + brand, 20, brandTacs.some(t => imei.startsWith(t)));

  // ── 2. IMEI Luhn checksum valid (5)
  add('IMEI Luhn', 5, validateIMEI(imei));

  // ── 3. MAC OUI matches brand pool (15)
  const mac = ids.wifiMac || generateMAC(brand, seed);
  const macOui = mac.split(':').slice(0, 3).map(h => parseInt(h, 16));
  const ouiPool = BRAND_OUIS[brand] || OUIS;
  const macBrandMatch = ouiPool.some(o => o[0] === macOui[0] && o[1] === macOui[1] && o[2] === macOui[2]);
  add('MAC OUI → ' + brand, 15, macBrandMatch);

  // ── 4. Serial format matches brand convention (10)
  const serial = ids.serial || generateSerial(brand, seed, '');
  let serialOk = false;
  if (brand === 'google')       serialOk = /^[A-HJ-NP-Z0-9]{7}$/i.test(serial);
  else if (brand === 'samsung') serialOk = /^[RSXZ][A-Z0-9]{2}[A-Z][A-Z0-9]{7,}$/i.test(serial);
  else                          serialOk = serial.length >= 8 && /^[A-Z0-9]+$/i.test(serial);
  add('Serial → ' + brand, 10, serialOk);

  // ── 5. IMSI valid US carrier (10)
  const imsi = ids.imsi || generateIMSI(profileName, seed);
  const mccMnc = imsi.substr(0, 6);
  add('IMSI carrier', 10, validateIMSI(imsi));

  // ── 6. ICCID format valid (10)
  const iccid = ids.iccid || generateICCID(profileName, seed);
  add('ICCID format', 10, validateICCID(iccid));

  // ── 7. Phone number valid NANP (10)
  const phone = ids.phone || generatePhoneNumber(profileName, seed);
  add('Phone NANP', 10, validatePhone(phone));

  // ── 8. Android ID (hex 16) (5)
  const aid = ids.androidId || generateAndroidId(seed);
  add('Android ID', 5, validateAndroidId(aid));

  // ── 9. GSF ID (hex 16) (5)
  const gsf = ids.gsfId || generateGsfId(seed);
  add('GSF ID', 5, validateGsfId(gsf));

  // ── 10. Boot ID UUID v4 (5)
  const boot = ids.bootId || generateBootId(seed);
  add('Boot ID (UUID)', 5, validateBootId(boot));

  // ── 11. Widevine ID (hex 32) (5)
  const wv = ids.widevineId || generateWidevineId(seed);
  add('Widevine ID', 5, validateWidevineId(wv));

  const max = checks.reduce((s, c) => s + c.weight, 0);
  const got = checks.reduce((s, c) => s + (c.passed ? c.weight : 0), 0);
  return { score: Math.round((got / max) * 100), checks };
}

// ─── UUID v4 generator (for Media DRM ID, Advertising ID) ────────────────────
export function generateUUID(seed) {
  const rng = new MT64(seed);
  const h8 = () => (Number(rng.gen() & 0xFFFFFFFFn) >>> 0).toString(16).padStart(8, '0');
  const h4 = () => Number(rng.gen() & 0xFFFFn).toString(16).padStart(4, '0');
  const a  = h8();
  const b  = h4();
  const c  = ((Number(rng.gen() & 0x0FFFn)) | 0x4000).toString(16).padStart(4, '0');
  const d  = ((Number(rng.gen() & 0x3FFFn)) | 0x8000).toString(16).padStart(4, '0');
  const e  = h8() + h4();
  return `${a}-${b}-${c}-${d}-${e}`;
}

// ─── WiFi SSID generator ──────────────────────────────────────────────────────
const _SSID_PFX = ['HOME','NETGEAR','TP-LINK','ASUS','Linksys','XFINITY','Spectrum','ATT','Verizon','MyWiFi'];
export function generateWifiSsid(seed) {
  const rng = new MT64(seed + 777);
  const pfx = _SSID_PFX[Number(rng.gen() % BigInt(_SSID_PFX.length))];
  const sfx = Number(rng.gen() & 0xFFFFn).toString(16).toUpperCase().padStart(4, '0');
  return `${pfx}-${sfx}`;
}

// ─── Gmail account generator ──────────────────────────────────────────────────
const _FN = ['alex','jordan','morgan','taylor','casey','riley','avery','blake','quinn','reese','sage','drew','cameron','harper','skyler'];
const _LN = ['smith','johnson','williams','brown','jones','davis','miller','wilson','moore','anderson','thomas','jackson','white','harris','martin'];
export function generateGmail(seed) {
  const rng = new MT64(seed + 999);
  const fn  = _FN[Number(rng.gen() % BigInt(_FN.length))];
  const ln  = _LN[Number(rng.gen() % BigInt(_LN.length))];
  const num = Number(rng.gen() % 900n) + 100;
  return `${fn}.${ln}${num}@gmail.com`;
}

export { US_CITIES_100, CARRIER_NAMES, IMSI_POOLS };
